# scripting languages
This workspace include both .cpp and .py executable files for flexibility and robustness, 
and the default language is c++ because of its high effectiveness.


# usage of roslaunch
NOTE that at present galil ,hyperion and YAMAHA (serial port) provide c++ support.
Use  $roslaunch galil_mixed eye_op_robot.launch                    to evoke .cpp executable files
and  $roslaunch galil_mixed eye_op_robot.launch file_suffix:=.py   to evoke .py executable files


# python import tips
In file "galil_overall_listener.py", we "import gclib_python.example". 
This syntax is possible only if there is a "__init__.py" file in folder "gclib_python". 
The same applies to "from . import gclib" in "example.py".


# version control
Add "add_definitions(-std=c++11)" to the first line of CMakeLists.txt for compilation. It is version control for c++.
All .py files add #!usr/bin/env python3 for version control.


# 
NOTE that 'omni_packages' is not a ROS package, but those four folders inside it are. 'omni_packages' is just for better file structure.


# about API
Omni phantom API is inside folder 'omni_packages'. See 'omni_packages/README.md' for installation guidance.
Hyperion API is in 'hyperion_mixed/script'.
