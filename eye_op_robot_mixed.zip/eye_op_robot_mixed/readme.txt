This workspace include both .cpp and .py executable files for flexibility and robustness, 
and the default language is c++ because of its high effectiveness.

NOTE that at present only galil provides c++ support.
Use  $roslaunch galil_mixed eye_op_robot.launch                    to evoke .cpp executable files
and  $roslaunch galil_mixed eye_op_robot.launch file_suffix:=.py   to evoke .py executable files

In file "galil_overall_listener.py", we "import gclib_python.example". 
This syntax is possible only if there is a "__init__.py" file in folder "gclib_python". 
The same applies to "from . import gclib" in "example.py".
