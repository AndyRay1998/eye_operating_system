#!/usr/bin/env python
# REMEMBER: chmod +x XX.py
import rospy
from std_msgs.msg import Float32MultiArray

def callback1(data1):
    rospy.loginfo(rospy.get_caller_id() + " heard data1")

def callback2(data2):
    rospy.loginfo(rospy.get_caller_id() + " heard data2")

def galil_listener():
    rospy.init_node('Galil_overall_listener', anonymous=False)
    rospy.Subscriber("Hyperion_data", Float32MultiArray, callback1)
    rospy.Subscriber("Omni_data", Float32MultiArray, callback2)
    # spin() simply keeps python from exiting until this node is stopped
    rospy.spin()

if __name__ == '__main__':
    galil_listener()
